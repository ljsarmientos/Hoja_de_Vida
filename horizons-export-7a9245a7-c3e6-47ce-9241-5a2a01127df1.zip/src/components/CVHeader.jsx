import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Download, Upload } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const CVHeader = ({ onFileChange, cvFileUrl }) => {
  const fileInputRef = useRef(null);

  const handleButtonClick = () => {
    if (cvFileUrl) {
      const link = document.createElement('a');
      link.href = cvFileUrl;
      link.setAttribute('download', 'CV-Leydi-Sarmiento.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file && file.type === "application/pdf") {
      onFileChange(file);
      toast({
        title: "✅ Archivo cargado",
        description: `Has cargado: ${file.name}. Ahora el botón descargará este archivo.`,
        duration: 4000
      });
    } else if (file) {
      toast({
        variant: "destructive",
        title: "❌ Archivo no válido",
        description: "Por favor, selecciona un archivo en formato PDF.",
        duration: 4000
      });
    }
  };

  return (
    <div className="flex flex-col md:flex-row justify-between items-center mb-8 bg-white rounded-2xl shadow-xl p-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Mi Hoja de Vida</h1>
      </div>
      <div className="flex gap-4 mt-4 md:mt-0">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept=".pdf"
        />
        <Button onClick={handleButtonClick} className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white px-6 py-3 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200">
          {cvFileUrl ? <Download className="w-4 h-4 mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
          Descargar CV
        </Button>
      </div>
    </div>
  );
};

export default CVHeader;