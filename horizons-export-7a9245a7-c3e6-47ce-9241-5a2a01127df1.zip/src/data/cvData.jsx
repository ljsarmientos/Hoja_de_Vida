import React from 'react';
import { Settings, Monitor, Wifi, Database, Code, Shield } from 'lucide-react';

export const personalInfo = {
  name: "Leydi Sarmiento",
  title: "Técnico en Sistemas",
  phone: "(3105373502)",
  email: "leidyjohanaarmiento1973@gmail.com",
  address: "Calle 6 Bis # 78 C 76",
  profile: "Soy una persona proactiva y creativa. Me gusta trabajar en equipo y dar soluciones para optimizar las tareas. Capacitada en gestión de proyectos."
};

export const experience = [{
  company: "BDO Colombia",
  period: "19 de diciembre de 2021 - 19 de junio de 2022",
  responsibilities: ["Soporte técnico in situ y remoto, incluyendo mesa de ayuda y atención a usuarios administrativos, docentes y estudiantes.", "Mantenimiento preventivo y correctivo de equipos de cómputo, tanto a nivel de hardware como de la actualización y optimización de sistemas operativos.", "Gestión de redes básicas, configuración de dispositivos y resolución de problemas de conectividad.", "Administración y gestión de inventarios de hardware y software, asegurando el control y seguimiento de los equipos.", "Manejo de herramientas de soporte remoto y documentación de incidentes para mejorar la eficiencia del servicio técnico."]
}, {
  company: "Universidad Pedagógica Nacional",
  period: "10 de noviembre de 2022 - 18 de diciembre de 2024",
  responsibilities: ["Instalación y configuración de software especializado para uso académico y administrativo.", "Conocimientos en soporte básico de Azure, así como en procesos de virtualización.", "Experiencia en implementación y evaluación de procesos tecnológicos, garantizando el correcto funcionamiento de los sistemas informáticos."]
}];

export const education = {
  degree: "TECNÓLOGO EN ANÁLISIS Y DESARROLLO DE SOFTWARE",
  institution: "UNIVERSIDAD SAN BUENAVENTURA",
  previousEducation: "Cursando 4 semestre. Adicionalmente, Técnico en Sistemas - Culminado mis estudios como Técnica en Sistemas, certificada por el SENA."
};

export const skills = [{
  name: "Soporte Técnico",
  level: 95,
  icon: <Settings className="w-4 h-4" />
}, {
  name: "Administración de Sistemas",
  level: 90,
  icon: <Monitor className="w-4 h-4" />
}, {
  name: "Redes y Conectividad",
  level: 85,
  icon: <Wifi className="w-4 h-4" />
}, {
  name: "Gestión de Inventarios",
  level: 88,
  icon: <Database className="w-4 h-4" />
}, {
  name: "Virtualización",
  level: 80,
  icon: <Code className="w-4 h-4" />
}, {
  name: "Azure",
  level: 75,
  icon: <Shield className="w-4 h-4" />
}];

export const languages = [{
  name: "Español",
  level: "Nativo"
}];