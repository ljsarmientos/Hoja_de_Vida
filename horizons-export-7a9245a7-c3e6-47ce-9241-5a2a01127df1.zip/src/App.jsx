
import React, { useState, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Monitor, Award } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Toaster } from '@/components/ui/toaster';
import CVHeader from '@/components/CVHeader';
import VisualCV from '@/components/VisualCV';
import AtsCV from '@/components/AtsCV';

function App() {
  const [activeTab, setActiveTab] = useState('visual');
  const [cvFileUrl, setCvFileUrl] = useState(null);

  const handleFileChange = useCallback((file) => {
    if (file) {
      const fileUrl = URL.createObjectURL(file);
      setCvFileUrl(fileUrl);
    }
  }, []);

  return (
    <>
      <Helmet>
        <title>Leydi Sarmiento - CV Profesional</title>
        <meta name="description" content="Hoja de vida profesional de Leydi Sarmiento, Técnico en Sistemas con experiencia en soporte técnico y administración de sistemas." />
        <meta property="og:title" content="Leydi Sarmiento - CV Profesional" />
        <meta property="og:description" content="Técnico en Sistemas especializado en soporte técnico, administración de sistemas y gestión de proyectos tecnológicos." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-fuchsia-100">
        <div className="container mx-auto px-4 py-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.6 }} 
            className="max-w-6xl mx-auto"
          >
            <CVHeader onFileChange={handleFileChange} cvFileUrl={cvFileUrl} />

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-white rounded-xl shadow-lg p-2">
                <TabsTrigger value="visual" className="rounded-lg py-3 px-6 data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-rose-500 data-[state=active]:text-white transition-all duration-300">
                  <Monitor className="w-4 h-4 mr-2" />
                  Versión Visual
                </TabsTrigger>
                <TabsTrigger value="ats" className="rounded-lg py-3 px-6 data-[state=active]:bg-gradient-to-r data-[state=active]:from-gray-500 data-[state=active]:to-gray-600 data-[state=active]:text-white transition-all duration-300">
                  <Award className="w-4 h-4 mr-2" />
                  Versión ATS
                </TabsTrigger>
              </TabsList>

              <TabsContent value="visual">
                <VisualCV />
              </TabsContent>

              <TabsContent value="ats">
                <AtsCV />
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
        <Toaster />
      </div>
    </>
  );
}

export default App;
